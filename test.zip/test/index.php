<?php 
require 'vendor/autoload.php';
$client = new \GuzzleHttp\Client();
$response = $client->request('POST', 'www.xxxx.cn/xx', array(
    'form_params' => array(
        'id' => 3666,
        'ck' => 'bdshare'    
    )
));
var_dump($response->getHeaderLine('Content-Length'));
